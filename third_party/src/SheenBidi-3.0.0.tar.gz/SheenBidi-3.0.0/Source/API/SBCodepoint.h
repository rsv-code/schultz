/*
 * Copyright (C) 2025 Muhammad Tayyab Akram
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef _SB_INTERNAL_CODEPOINT_H
#define _SB_INTERNAL_CODEPOINT_H

#include <SheenBidi/SBCodepoint.h>
#include <SheenBidi/SBCodepointSequence.h>

#include <API/SBBase.h>

SB_INTERNAL const void *SBCodepointGetBufferOffset(const void *buffer,
    SBStringEncoding encoding, SBUInteger index);

SB_INTERNAL void SBCodepointSkipToStart(const void *buffer, SBUInteger length,
    SBStringEncoding encoding, SBUInteger *index);

SB_INTERNAL void SBCodepointSkipToEnd(const void *buffer, SBUInteger length,
    SBStringEncoding encoding, SBUInteger *index);

SB_INTERNAL SBBoolean SBCodepointIsCanonicalEquivalentBracket(
    SBCodepoint codepoint, SBCodepoint bracket);

#endif
