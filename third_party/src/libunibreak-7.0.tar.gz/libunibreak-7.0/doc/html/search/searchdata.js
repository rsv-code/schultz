var indexSectionsWithContent =
{
  0: "abcdefgilnprstuw",
  1: "egilw",
  2: "egiltuw",
  3: "ilsu",
  4: "ceflnpsu",
  5: "gu",
  6: "begilrw",
  7: "cdegilprw",
  8: "aegiluw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros"
};

