var searchData=
[
  ['breakaction_0',['BreakAction',['../linebreak_8c.html#a440c1a7abb9df5e3fc1d27b9a39e3a8d',1,'linebreak.c']]],
  ['breakoutputtype_1',['BreakOutputType',['../linebreakdef_8h.html#af9b096718ede8429d17f4ad249a56433',1,'linebreakdef.h']]]
];
