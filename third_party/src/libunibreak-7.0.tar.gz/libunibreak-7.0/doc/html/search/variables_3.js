var searchData=
[
  ['lang_0',['lang',['../structLineBreakPropertiesLang.html#ae961b49d11e272adc590cf06e9f6100d',1,'LineBreakPropertiesLang::lang'],['../structLineBreakContext.html#aecd4a18e4138a674777aac6e7f07be4f',1,'LineBreakContext::lang']]],
  ['lb_5fprop_5fbmp_1',['lb_prop_bmp',['../linebreakdata_8c.html#a37258b0bd4a20b7486c59b0c28922eba',1,'lb_prop_bmp:&#160;linebreakdata.c'],['../linebreakdef_8h.html#a37258b0bd4a20b7486c59b0c28922eba',1,'lb_prop_bmp:&#160;linebreakdata.c']]],
  ['lb_5fprop_5flang_5fmap_2',['lb_prop_lang_map',['../linebreakdef_8c.html#ac273b24d54a00b96e356d52af3ac88b8',1,'lb_prop_lang_map:&#160;linebreakdef.c'],['../linebreakdef_8h.html#ac273b24d54a00b96e356d52af3ac88b8',1,'lb_prop_lang_map:&#160;linebreakdef.c']]],
  ['lb_5fprop_5fsupplementary_3',['lb_prop_supplementary',['../linebreakdata_8c.html#ac7635b488b30121688660b5d65c80a1a',1,'lb_prop_supplementary:&#160;linebreakdata.c'],['../linebreakdef_8h.html#ac7635b488b30121688660b5d65c80a1a',1,'lb_prop_supplementary:&#160;linebreakdata.c']]],
  ['lb_5fprop_5fsupplementary_5flen_4',['lb_prop_supplementary_len',['../linebreakdata_8c.html#a15a34394cf6a7be06d1100d330b2cb78',1,'lb_prop_supplementary_len:&#160;linebreakdata.c'],['../linebreakdef_8h.html#a15a34394cf6a7be06d1100d330b2cb78',1,'lb_prop_supplementary_len:&#160;linebreakdata.c']]],
  ['lbccur_5',['lbcCur',['../structLineBreakContext.html#a60c0c91ada87210e50a5ffee4cc6f899',1,'LineBreakContext']]],
  ['lbclast_6',['lbcLast',['../structLineBreakContext.html#ac6c5c4dab09a57c0a38f7a700f16c78c',1,'LineBreakContext']]],
  ['lbcnew_7',['lbcNew',['../structLineBreakContext.html#aa8cfc24887401c50ce6e74558ead05ea',1,'LineBreakContext']]],
  ['lbp_8',['lbp',['../structLineBreakPropertiesLang.html#ae191e36c0e857eecf98a3c35bbd66e46',1,'LineBreakPropertiesLang']]],
  ['lbplang_9',['lbpLang',['../structLineBreakContext.html#accc64c7bab810ea1ab8feec3dfe1f281',1,'LineBreakContext']]]
];
