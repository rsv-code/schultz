var searchData=
[
  ['ub_5fbsearch_0',['ub_bsearch',['../unibreakdef_8c.html#a076deefabad0418dd2b2691c9c256185',1,'ub_bsearch(utf32_t ch, const void *ptr, size_t count, size_t size):&#160;unibreakdef.h'],['../unibreakdef_8h.html#a076deefabad0418dd2b2691c9c256185',1,'ub_bsearch(utf32_t ch, const void *ptr, size_t count, size_t size):&#160;unibreakdef.h']]],
  ['ub_5fget_5fchar_5feaw_5fclass_1',['ub_get_char_eaw_class',['../eastasianwidthdef_8c.html#a4f307815ca17457d30f2283ff2b4d6a8',1,'ub_get_char_eaw_class(utf32_t ch):&#160;eastasianwidthdef.c'],['../eastasianwidthdef_8h.html#a4f307815ca17457d30f2283ff2b4d6a8',1,'ub_get_char_eaw_class(utf32_t ch):&#160;eastasianwidthdef.c']]],
  ['ub_5fget_5fnext_5fchar_5futf16_2',['ub_get_next_char_utf16',['../unibreakdef_8c.html#abea7cf98b11b45770e5f2ca16720e65c',1,'ub_get_next_char_utf16(const void *sv, size_t len, size_t *ip):&#160;unibreakdef.c'],['../unibreakdef_8h.html#abea7cf98b11b45770e5f2ca16720e65c',1,'ub_get_next_char_utf16(const void *sv, size_t len, size_t *ip):&#160;unibreakdef.c']]],
  ['ub_5fget_5fnext_5fchar_5futf32_3',['ub_get_next_char_utf32',['../unibreakdef_8c.html#a5af6a46a5fa7a3586f290e96d2384cb9',1,'ub_get_next_char_utf32(const void *sv, size_t len, size_t *ip):&#160;unibreakdef.c'],['../unibreakdef_8h.html#a5af6a46a5fa7a3586f290e96d2384cb9',1,'ub_get_next_char_utf32(const void *sv, size_t len, size_t *ip):&#160;unibreakdef.c']]],
  ['ub_5fget_5fnext_5fchar_5futf8_4',['ub_get_next_char_utf8',['../unibreakdef_8c.html#a570b17d839e2d585dbf1ea56b896ebff',1,'ub_get_next_char_utf8(const void *sv, size_t len, size_t *ip):&#160;unibreakdef.c'],['../unibreakdef_8h.html#a570b17d839e2d585dbf1ea56b896ebff',1,'ub_get_next_char_utf8(const void *sv, size_t len, size_t *ip):&#160;unibreakdef.c']]],
  ['ub_5fis_5fextended_5fpictographic_5',['ub_is_extended_pictographic',['../emojidef_8c.html#a538e0aae0f78469f3cd45c53d0a94857',1,'ub_is_extended_pictographic(utf32_t ch):&#160;emojidef.c'],['../emojidef_8h.html#a538e0aae0f78469f3cd45c53d0a94857',1,'ub_is_extended_pictographic(utf32_t ch):&#160;emojidef.c']]],
  ['ub_5fis_5fop_5feast_5fasian_6',['ub_is_op_east_asian',['../eastasianwidthdata_8c.html#a913035579cde9bbb66b109713859de52',1,'ub_is_op_east_asian(utf32_t ch):&#160;eastasianwidthdata.c'],['../eastasianwidthdef_8h.html#a913035579cde9bbb66b109713859de52',1,'ub_is_op_east_asian(utf32_t ch):&#160;eastasianwidthdata.c']]],
  ['ub_5flang_5fflags_7',['UB_LANG_FLAGS',['../linebreakdef_8h.html#a126e7fe4fe48ee0ca5036cfd6c23fe80',1,'linebreakdef.h']]],
  ['ub_5flb25_5fopt_5fhack_8',['UB_LB25_OPT_HACK',['../linebreak_8c.html#a8420e381b5107d222be7a714e5ed06fb',1,'linebreak.c']]],
  ['unibreak_5flazy_5fincb_9',['UNIBREAK_LAZY_INCB',['../graphemebreak_8c.html#a5cbd48a6d8ac338103dc02bdb8d4f61a',1,'graphemebreak.c']]],
  ['unibreak_5futf_5ftypes_5fdefined_10',['UNIBREAK_UTF_TYPES_DEFINED',['../unibreakbase_8h.html#ac9149d5a4efc8690a97d07338fc9eb94',1,'unibreakbase.h']]],
  ['unibreak_5fversion_11',['UNIBREAK_VERSION',['../unibreakbase_8h.html#ae61a59be2ea65292900e5cd8699ed3b2',1,'unibreakbase.h']]],
  ['unibreak_5fversion_12',['unibreak_version',['../unibreakbase_8c.html#a00447944791d6ca9af108a6e14d85470',1,'unibreak_version:&#160;unibreakbase.c'],['../unibreakbase_8h.html#a00447944791d6ca9af108a6e14d85470',1,'unibreak_version:&#160;unibreakbase.c']]],
  ['unibreakbase_2ec_13',['unibreakbase.c',['../unibreakbase_8c.html',1,'']]],
  ['unibreakbase_2eh_14',['unibreakbase.h',['../unibreakbase_8h.html',1,'']]],
  ['unibreakdef_2ec_15',['unibreakdef.c',['../unibreakdef_8c.html',1,'']]],
  ['unibreakdef_2eh_16',['unibreakdef.h',['../unibreakdef_8h.html',1,'']]],
  ['utf16_5ft_17',['utf16_t',['../unibreakbase_8h.html#a4dce96cad338d9281612277b2d80950c',1,'unibreakbase.h']]],
  ['utf32_5ft_18',['utf32_t',['../unibreakbase_8h.html#a4f775bae0642c213be2c526018283c25',1,'unibreakbase.h']]],
  ['utf8_5ft_19',['utf8_t',['../unibreakbase_8h.html#a6103b2105588f239c593e779e605038a',1,'unibreakbase.h']]]
];
