var searchData=
[
  ['graphemebreak_2ec_0',['graphemebreak.c',['../graphemebreak_8c.html',1,'']]],
  ['graphemebreak_2eh_1',['graphemebreak.h',['../graphemebreak_8h.html',1,'']]],
  ['graphemebreakdata_2ec_2',['graphemebreakdata.c',['../graphemebreakdata_8c.html',1,'']]],
  ['graphemebreakdef_2eh_3',['graphemebreakdef.h',['../graphemebreakdef_8h.html',1,'']]]
];
