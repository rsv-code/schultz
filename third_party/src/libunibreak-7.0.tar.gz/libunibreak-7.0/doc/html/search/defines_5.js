var searchData=
[
  ['ub_5flang_5fflags_0',['UB_LANG_FLAGS',['../linebreakdef_8h.html#a126e7fe4fe48ee0ca5036cfd6c23fe80',1,'linebreakdef.h']]],
  ['ub_5flb25_5fopt_5fhack_1',['UB_LB25_OPT_HACK',['../linebreak_8c.html#a8420e381b5107d222be7a714e5ed06fb',1,'linebreak.c']]],
  ['unibreak_5flazy_5fincb_2',['UNIBREAK_LAZY_INCB',['../graphemebreak_8c.html#a5cbd48a6d8ac338103dc02bdb8d4f61a',1,'graphemebreak.c']]],
  ['unibreak_5futf_5ftypes_5fdefined_3',['UNIBREAK_UTF_TYPES_DEFINED',['../unibreakbase_8h.html#ac9149d5a4efc8690a97d07338fc9eb94',1,'unibreakbase.h']]],
  ['unibreak_5fversion_4',['UNIBREAK_VERSION',['../unibreakbase_8h.html#ae61a59be2ea65292900e5cd8699ed3b2',1,'unibreakbase.h']]]
];
