var searchData=
[
  ['flangcjk_0',['fLangCjk',['../structLineBreakContext.html#a8f5e23199371cc6984427cea0cc29fd8',1,'LineBreakContext']]],
  ['flangstrict_1',['fLangStrict',['../structLineBreakContext.html#a87b4ebd05daf328e24c4a2c93b9edc44',1,'LineBreakContext']]],
  ['flb21ahebrew_2',['fLb21aHebrew',['../structLineBreakContext.html#aae9c8c4e457a7c31683779d095532251',1,'LineBreakContext']]],
  ['flb25mark_3',['fLb25Mark',['../structLineBreakContext.html#a79ea3167ba1861d0b06fc31b575477c3',1,'LineBreakContext']]],
  ['flb8azwj_4',['fLb8aZwj',['../structLineBreakContext.html#a54024680e48e955ed6635f51a18b4366',1,'LineBreakContext']]]
];
