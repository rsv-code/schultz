var searchData=
[
  ['indicconjunctbreakproperties_0',['IndicConjunctBreakProperties',['../structIndicConjunctBreakProperties.html',1,'']]]
];
