var searchData=
[
  ['poslast_0',['posLast',['../structLineBreakContext.html#a566c7f8b79771fdfb13d9e8a113e58ca',1,'LineBreakContext']]],
  ['poslb25fixup_1',['posLb25Fixup',['../structLineBreakContext.html#ad84aeb6a0bc0cdb86da3d4db45500d18',1,'LineBreakContext']]],
  ['prh_5fbrk_2',['PRH_BRK',['../linebreak_8c.html#a440c1a7abb9df5e3fc1d27b9a39e3a8da952ca85ab87da029497df2b4195df7d6',1,'linebreak.c']]],
  ['prop_3',['prop',['../structEastAsianWidthProperties.html#afb73ee1d73eac784ecb0105e6ff2030a',1,'EastAsianWidthProperties::prop'],['../structGraphemeBreakProperties.html#ac26f2959ac263c1e51df9cffb8b3ea98',1,'GraphemeBreakProperties::prop'],['../structIndicConjunctBreakProperties.html#a2567f00cafec6cd1bc388aeb6e2e8cdc',1,'IndicConjunctBreakProperties::prop'],['../structLineBreakProperties.html#a46d34ea3f514f8f082d92a441a6665ba',1,'LineBreakProperties::prop'],['../structWordBreakProperties.html#a30f8834130c9420301b1e94f66cbf4a0',1,'WordBreakProperties::prop']]]
];
