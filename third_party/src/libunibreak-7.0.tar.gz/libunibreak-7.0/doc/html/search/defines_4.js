var searchData=
[
  ['linebreak_5fallowbreak_0',['LINEBREAK_ALLOWBREAK',['../linebreak_8h.html#a229f34b0b72ccb2e53d0936a1e61a363',1,'linebreak.h']]],
  ['linebreak_5findeterminate_1',['LINEBREAK_INDETERMINATE',['../linebreak_8h.html#a18b9c9e4746dd51bf677f76bb1c1d585',1,'linebreak.h']]],
  ['linebreak_5finsideachar_2',['LINEBREAK_INSIDEACHAR',['../linebreak_8h.html#a5adf3d4831b89cb3e40e9bd31a73a39d',1,'linebreak.h']]],
  ['linebreak_5fmustbreak_3',['LINEBREAK_MUSTBREAK',['../linebreak_8h.html#a367d64258fd90864a467687cd1736b77',1,'linebreak.h']]],
  ['linebreak_5fnobreak_4',['LINEBREAK_NOBREAK',['../linebreak_8h.html#add176a107633817050bedf6eb4f491cc',1,'linebreak.h']]],
  ['linebreak_5fundefined_5',['LINEBREAK_UNDEFINED',['../linebreak_8c.html#a2b395925536433cb06d95290f42ca4ff',1,'linebreak.c']]]
];
